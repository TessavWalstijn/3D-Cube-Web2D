grote en voormaat:
    eyes:       200 x 100 
    iris:       200 x 100
    mouth:      200 x 100
    eyebrows:   200 x 50
    partekels:  30 x 30

    <name>.png

per gevoel:
    ogen & iris {
        1 maal
    }

    mouth {
        links boven *1 *2,
        rechts boven *1 *2,
        boven *1,
        links,
        midden,
        rechts,
        links onder *1 *2,
        rechts onder *1 *2,
        onder *1,
    }

    eyebrows {
        1 maal of als je het leuk vind
        een links en rechts er bij *2
    }

partekels:
    tranen

gevoelens:
    janken                  boos
    supper verdrietig       beetje boos
    heel verdrietig         shagerijnig             
    verdrietig              beetje shagerijnig      supper nieuwsgierig (anders blij dan supper blij)
    beetje verdrietig       geëriteerd              nieuwsgierig
    neutraal                beetje geëriteerd       beetje nieuwsgierig
    beetje blij             
    blij                    beetje verlegen
    heel blij               verlegen
    supper blij             heel verlegen
        
inspiratie:
    https://image.shutterstock.com/z/stock-vector--collection-of-cute-lovely-kawaii-emoticon-emoji-doodle-cartoon-face-smile-happy-wink-403598797.jpg
    https://image.shutterstock.com/z/stock-vector-sketched-facial-expressions-set-set-of-hand-drawn-funny-cartoon-faces-vector-illustration-309929366.jpg
    https://thumb1.shutterstock.com/display_pic_with_logo/1835936/345219554/stock-photo-set-of-funny-cartoon-faces-different-emotions-isolated-on-white-345219554.jpg
    https://s-media-cache-ak0.pinimg.com/236x/29/b4/c2/29b4c2f87af7d16c26089a540734a59d.jpg
    http://image.shutterstock.com/z/stock-vector-cartoon-faces-with-various-expressions-vector-illustration-112284389.jpg
    http://image.shutterstock.com/display_pic_with_logo/501640/501640,1309851757,4/stock-vector-cartoon-faces-for-humor-or-comics-design-80434189.jpg

***
*1 ietsjes verdrietiger
*2 als je dit doet moet het bij elk gevoel
    aan jou de keuze
***